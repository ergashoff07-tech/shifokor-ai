package uz.shifokorai

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.speech.RecognizerIntent
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private lateinit var web: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var cameraUri: Uri? = null
    private var lastWasCamera = false
    private var pendingVoiceId: String? = null
    private var pendingMapQuery: String? = null
    private val exec = Executors.newCachedThreadPool()
    private val prefs by lazy { getSharedPreferences("shifokor", MODE_PRIVATE) }

    companion object {
        private const val REQ_FILE = 11
        private const val REQ_VOICE = 12
        private const val REQ_LOC = 13
        // Tez modellar birinchi. Band (503), limit (429) yoki topilmasa — keyingisiga o'tiladi.
        private val TEXT_MODELS = listOf("gemini-2.5-flash-lite", "gemini-2.5-flash", "gemini-flash-lite-latest", "gemini-2.0-flash", "gemini-flash-latest")
        private val IMAGE_MODELS = listOf("gemini-2.5-flash", "gemini-2.5-flash-lite", "gemini-flash-latest", "gemini-2.0-flash", "gemini-flash-lite-latest")
        private val RETRY_CODES = setOf(404, 408, 429, 500, 502, 503, 504)
    }

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#0F2B8A")

        web = WebView(this)
        setContentView(web)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            mediaPlaybackRequiresUserGesture = false
            textZoom = 100
        }
        web.overScrollMode = View.OVER_SCROLL_NEVER

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url
                if (url.scheme == "file") return false
                openExternal(url)
                return true
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                lastWasCamera = params.isCaptureEnabled
                val intent = if (lastWasCamera) cameraIntent() else galleryIntent()
                return try {
                    startActivityForResult(intent, REQ_FILE)
                    true
                } catch (e: Exception) {
                    if (lastWasCamera) {
                        lastWasCamera = false
                        try {
                            startActivityForResult(galleryIntent(), REQ_FILE)
                            return true
                        } catch (_: Exception) { }
                    }
                    fileCallback?.onReceiveValue(null)
                    fileCallback = null
                    false
                }
            }
        }

        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")
    }

    private fun cameraIntent(): Intent {
        val dir = File(cacheDir, "images").apply { mkdirs() }
        val file = File(dir, "rx_${System.currentTimeMillis()}.jpg")
        val uri = FileProvider.getUriForFile(this, "$packageName.files", file)
        cameraUri = uri
        return Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
            putExtra(MediaStore.EXTRA_OUTPUT, uri)
            addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    private fun galleryIntent(): Intent =
        Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "image/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQ_FILE -> {
                val cb = fileCallback
                fileCallback = null
                if (cb == null) return
                if (resultCode != RESULT_OK) {
                    cb.onReceiveValue(null)
                    return
                }
                val uri: Uri? = if (lastWasCamera) cameraUri else data?.data
                cb.onReceiveValue(uri?.let { arrayOf(it) })
            }
            REQ_VOICE -> {
                val id = pendingVoiceId ?: return
                pendingVoiceId = null
                val text = if (resultCode == RESULT_OK)
                    data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() ?: ""
                else ""
                js("window.__voice&&window.__voice(${JSONObject.quote(id)},${JSONObject.quote(text)})")
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_LOC) openMapsNow()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("(window.appBack&&window.appBack())?'1':'0'") { r ->
            if (r?.contains("1") != true) {
                @Suppress("DEPRECATION")
                super.onBackPressed()
            }
        }
    }

    private fun js(code: String) = runOnUiThread { web.evaluateJavascript(code, null) }

    private fun openExternal(uri: Uri) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (_: Exception) { }
    }

    // ───────── Maps ─────────
    private fun hasLocationPermission(): Boolean =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun openMaps(query: String) {
        pendingMapQuery = query
        if (hasLocationPermission()) {
            openMapsNow()
        } else {
            requestPermissions(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
                REQ_LOC
            )
        }
    }

    private fun openMapsNow() {
        val q = pendingMapQuery ?: return
        pendingMapQuery = null
        var best: Location? = null
        if (hasLocationPermission()) {
            try {
                val lm = getSystemService(LOCATION_SERVICE) as LocationManager
                for (p in lm.getProviders(true)) {
                    val l = lm.getLastKnownLocation(p) ?: continue
                    if (best == null || l.time > best.time) best = l
                }
            } catch (_: SecurityException) { }
        }
        val enc = Uri.encode(q)
        val loc = best
        val url = if (loc != null)
            "https://yandex.uz/maps/?ll=${loc.longitude},${loc.latitude}&z=14&text=$enc"
        else
            "https://yandex.uz/maps/?text=$enc"
        openExternal(Uri.parse(url))
    }

    // ───────── Gemini ─────────
    private fun callGemini(request: String): String {
        val key = prefs.getString("key", "")?.trim() ?: ""
        if (key.isEmpty()) return JSONObject().put("status", 0).put("error", "nokey").toString()
        val base = try {
            JSONObject(request).getJSONObject("payload")
        } catch (e: Exception) {
            return JSONObject().put("status", 0).put("error", "bad_request").toString()
        }
        val hasImage = base.toString().contains("inline_data")
        val models = if (hasImage) IMAGE_MODELS else TEXT_MODELS
        var last = JSONObject().put("status", 0).put("error", "network")
        for (model in models) {
            val payload = payloadFor(base, model, hasImage)
            try {
                val conn = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                    .openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.connectTimeout = 15000
                conn.readTimeout = if (hasImage) 60000 else 35000
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                conn.setRequestProperty("x-goog-api-key", key)
                conn.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                conn.disconnect()
                last = JSONObject().put("status", code).put("body", body).put("model", model)
                if (code in RETRY_CODES) continue
                // thinkingConfig'ni qo'llamaydigan model 400 qaytarsa — keyingisiga
                if (code == 400 && body.contains("thinking", ignoreCase = true)) continue
                return last.toString()
            } catch (e: Exception) {
                last = JSONObject().put("status", 0).put("error", e.message ?: "network")
            }
        }
        return last.toString()
    }

    /** 2.5 modellarda "o'ylash"ni o'chiramiz — javob bir necha barobar tezlashadi. */
    // Retsept rasmida (qo'lyozma) aniqlik uchun ozgina o'ylashga ruxsat beriladi.
    private fun payloadFor(base: JSONObject, model: String, hasImage: Boolean): String {
        val p = JSONObject(base.toString())
        if (model.startsWith("gemini-2.5-")) {
            val budget = if (hasImage && model == "gemini-2.5-flash") 1024 else 0
            val gc = p.optJSONObject("generationConfig") ?: JSONObject().also { p.put("generationConfig", it) }
            gc.put("thinkingConfig", JSONObject().put("thinkingBudget", budget))
        }
        return p.toString()
    }

    // ───────── JS bridge ─────────
    inner class Bridge {
        @JavascriptInterface
        fun hasKey(): Boolean = !prefs.getString("key", "").isNullOrBlank()

        @JavascriptInterface
        fun setKey(k: String) {
            prefs.edit().putString("key", k.trim()).apply()
        }

        @JavascriptInterface
        fun gemini(id: String, request: String) {
            exec.execute {
                val res = callGemini(request)
                js("window.__gem&&window.__gem(${JSONObject.quote(id)},${JSONObject.quote(res)})")
            }
        }

        @JavascriptInterface
        fun openMaps(query: String) {
            runOnUiThread { this@MainActivity.openMaps(query) }
        }

        @JavascriptInterface
        fun call(number: String) {
            runOnUiThread { openExternal(Uri.parse("tel:$number")) }
        }

        @JavascriptInterface
        fun voice(id: String) {
            runOnUiThread {
                pendingVoiceId = id
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "uz-UZ")
                    putExtra(RecognizerIntent.EXTRA_PROMPT, "Gapiring…")
                }
                try {
                    startActivityForResult(intent, REQ_VOICE)
                } catch (_: Exception) {
                    pendingVoiceId = null
                    js("window.__voice&&window.__voice(${JSONObject.quote(id)},'',true)")
                }
            }
        }

        @JavascriptInterface
        fun statusBar(color: String, darkIcons: Boolean) {
            runOnUiThread {
                try {
                    window.statusBarColor = Color.parseColor(color)
                    @Suppress("DEPRECATION")
                    window.decorView.systemUiVisibility =
                        if (darkIcons) View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR else 0
                } catch (_: Exception) { }
            }
        }
    }
}
