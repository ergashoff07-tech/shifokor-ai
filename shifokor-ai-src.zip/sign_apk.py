"""Gradle debug APK ni 4-bayt tekislab, o'z imzo kaliti bilan (APK Signature Scheme v2) qayta imzolaydi.
usage: sign_apk.py IN.apk OUT.apk KEY.pem CERT.der
"""
import sys, struct, zipfile, hashlib, io
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding

old_apk, out_apk, key_pem, cert_der = sys.argv[1:5]

# ---------- rebuild zip with 4-byte alignment for stored entries ----------
zin = zipfile.ZipFile(old_apk)
buf = io.BytesIO()
zout = zipfile.ZipFile(buf, 'w')
for info in zin.infolist():
    data = zin.read(info.filename)
    if info.filename.startswith('META-INF/') and info.filename.upper().endswith(('.SF','.RSA','.DSA','.EC','.MF')):
        continue
    ni = zipfile.ZipInfo(info.filename, date_time=(2026, 10, 29, 0, 0, 0))
    ni.compress_type = info.compress_type
    ni.external_attr = info.external_attr
    ni.create_system = 0
    if ni.compress_type == zipfile.ZIP_STORED:
        # local header = 30 + len(name) + len(extra); pad extra so data starts at 4-byte boundary
        hdr_end = buf.tell() + 30 + len(ni.filename.encode())
        pad = (-hdr_end) % 4
        ni.extra = b'\x00' * pad
    zout.writestr(ni, data, compress_type=ni.compress_type, compresslevel=9)
zout.close()
apk = buf.getvalue()

# sanity: stored entries aligned
zchk = zipfile.ZipFile(io.BytesIO(apk))
for i in zchk.infolist():
    if i.compress_type == 0:
        lh = apk[i.header_offset:i.header_offset + 30]
        nlen, xlen = struct.unpack_from('<HH', lh, 26)
        assert (i.header_offset + 30 + nlen + xlen) % 4 == 0, i.filename

# ---------- APK Signature Scheme v2 ----------
eocd = apk.rfind(b'PK\x05\x06')
cd_size, cd_off = struct.unpack_from('<II', apk, eocd + 12)
sec1 = apk[:cd_off]; sec3 = apk[cd_off:eocd]; sec4 = bytearray(apk[eocd:])

def chunk_digest(parts):
    chunks = []
    for part in parts:
        for i in range(0, len(part), 1 << 20):
            c = part[i:i + (1 << 20)]
            chunks.append(hashlib.sha256(b'\xa5' + struct.pack('<I', len(c)) + c).digest())
    return hashlib.sha256(b'\x5a' + struct.pack('<I', len(chunks)) + b''.join(chunks)).digest()

digest = chunk_digest([sec1, sec3, bytes(sec4)])  # EOCD cd offset == start of signing block (== cd_off before insertion)

lp = lambda x: struct.pack('<I', len(x)) + x
ALG = 0x0103  # RSASSA-PKCS1-v1_5 with SHA2-256
key = serialization.load_pem_private_key(open(key_pem, 'rb').read(), None)
cert = open(cert_der, 'rb').read()
pub = key.public_key().public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)

digests = lp(lp(struct.pack('<I', ALG) + lp(digest)))
certs = lp(lp(cert))
signed_data = digests + certs + lp(b'')
sig = key.sign(signed_data, padding.PKCS1v15(), hashes.SHA256())
signer = lp(signed_data) + lp(lp(struct.pack('<I', ALG) + lp(sig))) + lp(pub)
v2_value = lp(lp(signer))

pair = struct.pack('<Q', 4 + len(v2_value)) + struct.pack('<I', 0x7109871a) + v2_value
block_size = len(pair) + 8 + 16
block = struct.pack('<Q', block_size) + pair + struct.pack('<Q', block_size) + b'APK Sig Block 42'

new_cd_off = cd_off + len(block)
struct.pack_into('<I', sec4, 16, new_cd_off)
open(out_apk, 'wb').write(sec1 + block + sec3 + bytes(sec4))
print('built', out_apk, len(sec1) + len(block) + len(sec3) + len(sec4))
